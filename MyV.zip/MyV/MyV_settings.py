# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'django-insecure-o$g&9zq50s%imp4-b9+n!ovkn(y2@hp^b8g)^ox251v86c4r+c'


#AWS settings
AWS_ACCESS_KEY_ID = 'AKIA2UC3F54IG43JGEFC'
AWS_SECRET_ACCESS_KEY = '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'
AWS_STORAGE_BUCKET_NAME = 'myv-aws-bucket'
AWS_S3_REGION_NAME = 'ap-northeast-2'


#Email settings
EMAIL_HOST = "smtp.gmail.com"
EMAIL_HOST_USER = "pt840072@gmail.com"
EMAIL_HOST_PASSWORD = "xgfl mugl vbwj pljx"